# SnapNest

SnapNest is an image-search website designed to help users discover visual inspiration by topic. Users will eventually be able to search for images and view them in a responsive gallery. I chose a cream and dark green colour palette to create a calm, nature-inspired appearance. I also included category chips and a Clear button to make the interface easier to use. The project is built with plain HTML, CSS, and JavaScript.
